package com.dicoding.a4githubku.ui

import android.content.Context
import android.os.Bundle
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dicoding.a4githubku.data.response.ItemsItem
import com.dicoding.a4githubku.ui.follow.FollowersFragment
import com.dicoding.a4githubku.ui.follow.FollowingFragment
import com.example.a4githubku.R

//class SectionPagerAdapter(fragment: Fragment, private val user: ItemsItem) : FragmentStateAdapter(fragment)  {
//    override fun getItemCount() = 2
//
//    override fun createFragment(position: Int): Fragment {
//        var fragment: Fragment? = null
//
//        when (position) {
//            0 -> {
//                fragment = FollowersFragment()
//                fragment.arguments = Bundle().apply {
//                    putString(EXTRA_USER, user.login)
//                }
//            }
//            1 -> fragment = FollowingFragment()
//        }
//
//        return fragment as Fragment
//    }
//
//    companion object {
//        const val EXTRA_USER = "extra_user"
//    }
//}

//class SectionPagerAdapter(private val mCtx: Context, fm: FragmentManager, data: Bundle) :
//    FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
//
//    private var fragmentBundle: Bundle
//
//    init {
//        fragmentBundle = data
//    }
//
//    @StringRes
//    private val TAB_TITLES = intArrayOf(R.string.tab_1, R.string.tab_2)
//
//    override fun getCount(): Int = 2
//
//    override fun getItem(position: Int): Fragment {
//        var fragment: Fragment? = null
//        when(position) {
//            0 -> fragment = FollowersFragment()
//            1 -> fragment = FollowingFragment()
//        }
//        fragment?.arguments = this.fragmentBundle
//        return fragment as Fragment
//    }
//
//    override fun getPageTitle(position: Int): CharSequence? {
//        return mCtx.resources.getString(TAB_TITLES[position])
//    }
//}


class SectionPagerAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {
    override fun createFragment(position: Int): Fragment {  // createFragment digunakan untuk menampilkan fragment sesuai dengan posisi tab-nya. Misalnya kode di atas untuk posisi 0 (tab pertama) menampilkan HomeFragment dan di posisi 1 (tab kedua) menampilkan ProfileFragment
        var fragment: Fragment? = null
        when (position) {
            0 -> fragment = FollowersFragment()
            1 -> fragment = FollowingFragment()
        }
        return fragment as Fragment
    }

    override fun getItemCount(): Int {  // getItemCount digunakan untuk menentukan jumlah tab yang ingin ditampilkan
        return 2
    }
}

//class SectionPagerAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {
//    var username: String = ""
//    override fun createFragment(position: Int): Fragment {
//        val fragment = FollowFragment()
//        fragment.arguments = Bundle().apply {
//            putInt(FollowFragment.ARG_POSITION, position + 1)
//            putString(FollowFragment.ARG_USERNAME, username)
//        }
//        return fragment
//    }
//    override fun getItemCount(): Int {
//        return 2
//    }
//}